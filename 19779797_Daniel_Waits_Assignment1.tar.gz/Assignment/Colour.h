void changeColour(char* colour);
void changeColourHighlight(char* colour);
void changeColourKnown(char* colour);
